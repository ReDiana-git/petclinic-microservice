package nl.nl0e0.consultationmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultationMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
