package nl.nl0e0.consultationmicroservice.entity.model;

public enum AppointmentState {
	INIT,CONSULTAION,PAYMENT, MEDICINE, DONE
}
